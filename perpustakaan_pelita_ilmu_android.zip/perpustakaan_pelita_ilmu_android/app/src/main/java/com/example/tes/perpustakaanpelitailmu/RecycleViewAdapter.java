package com.example.tes.perpustakaanpelitailmu;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONObject;

import java.util.ArrayList;

public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewAdapter.MyViewHolder> {

    private Context mContext;
    private ArrayList<String> array_merkmodel,array_jenis,array_tahun,array_jumlah,array_id_buku;
    ProgressDialog progressDialog;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView tv_merkmodel,tv_jenis,tv_tahun,tv_jumlah,tv_id_buku;
        public CardView cv_main;

        public MyViewHolder(View view) {
            super(view);
            cv_main = itemView.findViewById(R.id.cv_main);
            tv_merkmodel = itemView.findViewById(R.id.tv_merkmodel);
            tv_jenis = itemView.findViewById(R.id.tv_jenis);
            tv_tahun = itemView.findViewById(R.id.tv_tahun);
            tv_jumlah = itemView.findViewById(R.id.tv_jumlah);
            tv_id_buku = itemView.findViewById(R.id.tv_id_buku);

            progressDialog = new ProgressDialog(mContext);
        }
    }

    public RecycleViewAdapter(Context mContext, ArrayList<String> array_merkmodel,ArrayList<String> array_jenis,ArrayList<String> array_tahun,ArrayList<String> array_jumlah, ArrayList<String> array_id_buku) {
        super();
        this.mContext = mContext;
        this.array_merkmodel = array_merkmodel;
        this.array_jenis = array_jenis;
        this.array_tahun = array_tahun;
        this.array_jumlah = array_jumlah;
        this.array_id_buku = array_id_buku;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View itemView = layoutInflater.inflate(R.layout.template_rv,parent,false);
        return new RecycleViewAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        holder.tv_merkmodel.setText(array_merkmodel.get(position));
        holder.tv_jenis.setText(array_jenis.get(position));
        holder.tv_tahun.setText(array_tahun.get(position));
        holder.tv_jumlah.setText(array_jumlah.get(position));
        holder.tv_id_buku.setText(array_id_buku.get(position));
        holder.cv_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(mContext,Activity_Edit.class);
                i.putExtra("merkmodel",array_merkmodel.get(position));
                i.putExtra("jenis",array_jenis.get(position));
                i.putExtra("tahun",array_tahun.get(position));
                i.putExtra("jumlah",array_jumlah.get(position));
                i.putExtra("id_buku",array_id_buku.get(position));
                ((Activity_Main)mContext).startActivityForResult(i,2);
            }
        });
        holder.cv_main.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                new AlertDialog.Builder((Activity_Main)mContext)
                        .setMessage("Ingin menghapus data ini"+array_merkmodel.get(position)+" ?")
                        .setCancelable(false)
                        .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                progressDialog.setMessage("Menghapus...");
                                progressDialog.setCancelable(false);
                                progressDialog.show();

                                AndroidNetworking.post("https://44b4-180-254-139-224.ngrok.io/perpustakaan_pelita_ilmu/Android/hapusBuku.php")
                                        .addBodyParameter("id_buku",""+array_id_buku.get(position))
                                        .setPriority(Priority.MEDIUM)
                                        .build()
                                        .getAsJSONObject(new JSONObjectRequestListener() {
                                            @Override
                                            public void onResponse(JSONObject response) {
                                                progressDialog.dismiss();
                                                try {
                                                    Boolean status = response.getBoolean("status");
                                                    Log.d("status",""+status);
                                                    String result = response.getString("result");
                                                    if(status){
                                                        if(mContext instanceof Activity_Main){
                                                            ((Activity_Main)mContext).scrollRefresh();
                                                        }
                                                    }else{
                                                        Toast.makeText(mContext, ""+result, Toast.LENGTH_SHORT).show();
                                                    }
                                                }catch (Exception e){
                                                    e.printStackTrace();
                                                }
                                            }

                                            @Override
                                            public void onError(ANError anError) {
                                                anError.printStackTrace();
                                            }
                                        });
                            }
                        })
                        .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        })
                        .show();
                return false;
            }
        });

    }

    @Override
    public int getItemCount() {
        return array_merkmodel.size();
    }
}
